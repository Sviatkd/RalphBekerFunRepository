set.seed(124)
library(fwildclusterboot)
library(gt)
#Converting to TWFE#
df_did$Unit <- as.factor(df_did$Unit)
df_did$Year <- as.factor(df_did$Year)
model1 <- lm(CycleTraffic_bn ~ Unit+Year+did, data = df_did)
simpleboot <- boottest(model1,clustid = "Unit",param = "did",type="webb",B=9999)
model_event <- lm(CycleTraffic_bn ~ treated*Year+Unit,data = df_did)
postnames <- c("treated:Year2019","treated:Year2020","treated:Year2021","treated:Year2022")
modelplot(model_event,se=vcovHC(model_event,type="HC3"))
allevent <- grep("treated:",names(coef(model_event)),value = TRUE)
prenames <- allevent[!(allevent %in% postnames)]
pretest <- boottest(model_event,clustid = "Unit",param = prenames,type="webb",B=9999)
postCovid <- c("treated:Year2022")
preandCovid <- c("treated:Year2019","treated:Year2020","treated:Year2021")
#Making a Summary Table#
consttime <- boottest(model_event,clustid = "Unit",param = c(preandCovid,postCovid),R=c(1,1,1,-1),type="webb",B=9999)
reducedmodeltest <- tidy(simpleboot)
pretrendtest <- tidy(pretest)
constanttimeeffecttest <- tidy(consttime)
pretrendtest$term <- "sum(Allprecoefs)=0"
constanttimeeffecttest$term <- "DiDpreandcovid-DiDpostcovid=0"
bootresultscycling <- rbind(pretrendtest,constanttimeeffecttest,reducedmodeltest,tidy(wcb_p2))
gt(bootresultscycling) %>%
  tab_header(title = "Wild(Cluster=Unit/Region) Bootstrap Inference Results") %>%
  cols_label(term = "Test Specification", 
             estimate = "Estimate", 
             p.value = "p-value") %>%
  # 3. Format numbers (3 decimal places)
  fmt_number(columns = 2:6, decimals = 3) %>%
  # 4. Merge CI into one column (optional but looks nice)
  cols_merge(columns = c(conf.low, conf.high), pattern = "[{1}, {2}]") %>%
  cols_label(conf.low = "95% Conf. Interval")
model_placebo_space <- lm(CycleTraffic_bn ~ Unit+Year+ + did_placebo,
                          data = df_placebo_space)
wcb_p2 <- boottest(model_placebo_space,param = "did_placebo",clustid ="Unit", B = 9999,type = "Webb")
