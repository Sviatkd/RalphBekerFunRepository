library(readxl)
library(readxl)
library(tidyverse)
library(stargazer)
library(lmtest)
library(sandwich)
library(coefplot)
library(clubSandwich)
library(aod)
library(modelsummary)
library(gt)
library(fwildclusterboot)
set.seed(124)
no2quarterly <- FullDataset %>%
  mutate(yr_qtr = quarter(date, with_year = TRUE)) %>% 
  group_by(yr_qtr, Station) %>%
  summarise(mean_value = mean(pm10, na.rm = TRUE), .groups = "drop") %>%
  arrange(Station, yr_qtr) %>%
  group_by(Station) %>%
  mutate(
    pct_changepol = (mean_value - lag(mean_value)) / lag(mean_value) * 100
  ) %>%
  ungroup()
no2quarterly <- no2quarterly %>%
  mutate(City = case_when(
    str_detect(Station, regex("Birmingham", ignore_case = TRUE)) ~ "Birmingham",
    str_detect(Station, regex("Glasgow", ignore_case = TRUE))    ~ "Glasgow",
    str_detect(Station, regex("Leeds", ignore_case = TRUE))      ~ "Leeds",
    str_detect(Station, regex("London", ignore_case = TRUE))     ~ "London",
    str_detect(Station, regex("Manchester", ignore_case = TRUE)) ~ "Manchester",
    str_detect(Station, regex("Newcastle", ignore_case = TRUE))  ~ "Newcastle",
    str_detect(Station, regex("Sheffield", ignore_case = TRUE))  ~ "Sheffield",
    str_detect(Station, regex("Camden", ignore_case = TRUE))     ~ "London",
    str_detect(Station, regex("Salford", ignore_case = TRUE))    ~ "Salford",
    str_detect(Station, regex("Sunderland", ignore_case = TRUE)) ~ "Sunderland",
    str_detect(Station, regex("Westminster", ignore_case = TRUE)) ~ "London",
    TRUE ~ "Other" # Catch-all for anything missed
  ))
ggplot(no2quarterly,mapping = aes(x=yr_qtr,y=mean_value,colour = factor(Station)))+stat_summary(fun=mean,geom="line")+geom_vline(xintercept = 2019.2,linetype="dashed")+ ggtitle("Means with a policy breakpoint(No2)")
#Defining groups and Intervention Period#
intervention <- c(2019.2,2019.3,2019.4,2020.1,2020.2,2020.3,2020.4,2021.1,2021.2,2021.3,2021.4,2022.1,2022.2,2022.3,2022.4)
treatment <- c(
  "glasgow-anderston",
  "glasgow-byres road",
  "glasgow-high street",
  "glasgow-townhead",
  "GlasgowK"
)

control <- c(
  "manchester-oxford road",
  "ManchesterPic",
  "NewcastleC",
  "salford-eccles",
  "salford-m60"
)
panel_dfind <- no2quarterly %>%
  mutate(
    intervention = ifelse(yr_qtr %in% intervention, 1,0),
    control = ifelse(Station %in% control, 1, 0),
    treatment= ifelse(Station %in% treatment,1,0),
    did= intervention*treatment)
treatment_control_df <- panel_dfind %>%
  filter(treatment + control == 1,yr_qtr < 2023.1 & yr_qtr > 2015.1)
#Creating The Station specific counterfactual trend plots"
# 1. Calculate the average "Control Trend" across all control stations
control_trend <- treatment_control_df %>%
  filter(treatment == 0) %>%
  group_by(yr_qtr) %>%
  summarise(control_mean = mean(mean_value, na.rm = TRUE)) %>%
  mutate(control_drift = control_mean - first(control_mean)) # Movement relative to start


# 2. Calculate the pre-intervention baseline for each Treated Station
treated_baselines <- treatment_control_df %>%
  filter(treatment == 1, yr_qtr < 2019.2) %>%
  group_by(Station) %>%
  summarise(baseline_val = mean(mean_value, na.rm = TRUE))
# 3. Create the Counterfactual Data
counterfactual_data <- treated_baselines %>%
  crossing(control_trend) %>% # Merge every station with every time point
  mutate(counterfactual_val = baseline_val + control_drift)

# 4. Plotting
ggplot() +
  # Actual Treated Data (Solid Lines)
  geom_line(data = filter(treatment_control_df, treatment == 1), 
            aes(x = yr_qtr, y = mean_value, color = Station), 
            size = 0.8, alpha = 0.6) +
  # Pseudo-Counterfactual Data (Dashed Lines)
  geom_line(data = counterfactual_data, 
            aes(x = yr_qtr, y = counterfactual_val, color = Station), 
            linetype = "dashed", size = 0.8) +
  # Policy Intervention Line
  geom_vline(xintercept = 2019.2, linetype = "dotted", color = "black", size = 1) +
  labs(
    title = "Treated Station Trajectories vs. Pseudo-Counterfactuals",
    subtitle = "Solid = Actual | Dashed = Control Trend applied to Station Baseline",
    x = "Year.Quarter",
    y = "NO2 Level",
    caption = "Counterfactual based on mean movement of all control stations"
  ) +
  theme_minimal()
ggplot() +
  # Actual Treated Data (Solid Lines)
  geom_line(data = filter(treatment_control_df, treatment == 1), 
            aes(x = yr_qtr, y = mean_value, color = Station), 
            size = 0.8, alpha = 0.6) +
  # Pseudo-Counterfactual Data (Dashed Lines)
  geom_line(data = counterfactual_data, 
            aes(x = yr_qtr, y = counterfactual_val, color = Station), 
            linetype = "dashed", size = 0.8) +
  # Policy Intervention Line
  geom_vline(xintercept = 2019.2, linetype = "dotted", color = "black", size = 1) +
  labs(
    title = "Treated Station Trajectories vs. Pseudo-Counterfactuals",
    subtitle = "Solid = Actual | Dashed = Control Trend applied to Station Baseline",
    x = "Year.Quarter",
    y = "NO2 Level",
    caption = "Counterfactual based on mean movement of all control stations"
  ) +
  theme_minimal()
#Creating a Smooth Version#
library(broom)
# 1. Fit a LOESS model to the Control Group to capture the "Natural" trend
control_loess_mod <- loess(mean_value ~ yr_qtr, 
                           data = filter(treatment_control_df, treatment == 0), 
                           span = 0.75)

# 2. Create a prediction grid for the Control Trend
qtr_grid <- seq(min(treatment_control_df$yr_qtr), max(treatment_control_df$yr_qtr), by = 0.1)
control_trend_shape <- data.frame(yr_qtr = qtr_grid) %>%
  mutate(pred_val = predict(control_loess_mod, newdata = .)) %>%
  mutate(drift = pred_val - first(pred_val)) # Calculate movement relative to T=0

# 3. Get the pre-intervention mean for each Treated Station to use as the "Shift"
treated_starts <- treatment_control_df %>%
  filter(treatment == 1, yr_qtr < 2019.2) %>%
  group_by(Station) %>%
  summarise(start_mean = mean(mean_value, na.rm = TRUE))

# 4. Create the Counterfactual Data by applying the Control Drift to each Treated Start
loess_counterfactuals <- treated_starts %>%
  crossing(control_trend_shape) %>%
  mutate(counterfactual_loess = start_mean + drift)

# 5. Plot
ggplot() +
  # Actual Treated Stations (Individual LOESS lines)
  geom_smooth(data = filter(treatment_control_df, treatment == 1), 
              aes(x = yr_qtr, y = mean_value, color = Station), 
              method = "loess", se = FALSE, size = 1) +
  # Pseudo-Counterfactuals (Shifted Control LOESS - Dashed)
  geom_line(data = loess_counterfactuals, 
            aes(x = yr_qtr, y = counterfactual_loess, color = Station), 
            linetype = "dashed", alpha = 0.7, size = 0.8) +
  # Visual Aids
  geom_vline(xintercept = 2019.2, linetype = "dotted", size = 1) +
  labs(
    title = "Treated Stations vs. Smooth Conditional mean  Counterfactuals",
    subtitle = "Solid = Actual LOESS trend | Dashed = Control Group LOESS shape shifted to station baseline",
    x = "Year.Quarter",
    y = "NO2 Level (Shifted)",
    caption = "The divergence after the dotted line represents the estimated policy impact."
  ) +
  theme_minimal()
ggplot(treatment_control_df, aes(x = mean_value, fill = factor(intervention), color = factor(intervention))) +
  geom_density(alpha = 0.3) +
  # Use facet_wrap to create the side-by-side view
  facet_wrap(~treatment, labeller = as_labeller(c("0" = "Control", "1" = "Treatment"))) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_minimal() +
  labs(
    title = "Comparison of Densities(KDE)(NO2)",
    subtitle = "Side-by-side density plots of Treatment vs Control",
    x = "Mean Value",
    y = "Density",
    fill = "Intervention",
    color = "Intervention"
  ) +
  theme(legend.position = "bottom")
#Creating Density Plots#
ggplot(filter(treatment_control_df,treatment==1), aes(x = mean_value, fill = factor(intervention), color = factor(intervention))) +
  geom_density(alpha = 0.3) +
  # Use facet_wrap to create the side-by-side view
  facet_wrap(~Station) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_minimal() +
  labs(
    title = "Comparison of Densities(KDE)(NO2)",
    subtitle = "Side-by-side density plots of Treated London Stations",
    x = "Mean Value",
    y = "Density",
    fill = "Intervention",
    color = "Intervention"
  ) +
  theme(legend.position = "bottom")
ggplot(filter(treatment_control_df,treatment==0), aes(x = mean_value, fill = factor(intervention), color = factor(intervention))) +
  geom_density(alpha = 0.3) +
  # Use facet_wrap to create the side-by-side view
  facet_wrap(~Station) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_minimal() +
  labs(
    title = "Comparison of Densities(KDE)(NO2)",
    subtitle = "Side-by-side density plots of Control Stations",
    x = "Mean Value",
    y = "Density",
    fill = "Intervention",
    color = "Intervention"
  ) +
  theme(legend.position = "bottom")
#Estimating Models#
treatment_control_df$Station <- as.factor(treatment_control_df$Station)
treatment_control_df$yr_qtr <- as.factor(treatment_control_df$yr_qtr)
treatment_control_df$City <- as.factor(treatment_control_df$City)
treatment_control_df$did <-as.factor(treatment_control_df$did)
reducedmodel <- lm(mean_value~did+yr_qtr+Station,data=treatment_control_df)
treatment_control_df$ulez_id <- ifelse(treatment_control_df$did == 1, 
                                       as.character(treatment_control_df$Station), 
                                       "Control")
hetmodel <- lm(mean_value~did+did:Station+yr_qtr+Station,data=treatment_control_df)
eventmodel <- lm(mean_value~treatment*yr_qtr+Station,data=treatment_control_df)
#Estimating clustered and Jacknife robust se matrices#
hcr_vcov <- vcovHC(eventmodel,type = "HC3")
hcr_vcovh <- vcovHC(hetmodel,type = "HC3")
hcr_vcovr <- vcovHC(reducedmodel,type = "HC3")
cluster_vcov <- vcovCR(eventmodel,type = "CR2",cluster = treatment_control_df$Station)
cluster_vcovh <- vcovCR(hetmodel,type = "CR2",cluster = treatment_control_df$Station)
cluster_vcovr <- vcovCR(reducedmodel,type = "CR2",cluster = treatment_control_df$Station)
#Event Study Plots#
all_coefs <- names(coef(eventmodel))
qtr_coefs <- all_coefs[grep("treatment:yr_qtr", all_coefs)]
qtr_coefs <- qtr_coefs[order(gsub(".*\\)", "", qtr_coefs))]
modelplot(eventmodel,vcov = hcr_vcov,coef_omit = "^(?!.*treatment:)",color="darkblue")+geom_vline(xintercept=0)+labs(title="Event(2019.2) No2 Study,HC3(Jacknife) Corrected SE")+theme_classic()+ geom_hline(yintercept ="treatment:yr_qtr2019.2",linetype = "dashed", colour = "red")+coord_flip()+theme(axis.text.x = element_text(angle = 90))
modelplot(hetmodel,vcov = hcr_vcovh,coef_omit = "^(?!did1)",color="darkgreen")+geom_vline(xintercept=0)+labs(title="NO2 Heterogenous(Station) Average ULEZ Effects")
modelplot(eventmodel,vcov = cluster_vcov,coef_omit = "^(?!.*treatment:)",color="darkblue")+geom_vline(xintercept=0)+labs(title="Event(2019.2) No2 Study,Cluster(Station) Corrected SE")+theme_classic()+ geom_hline(yintercept ="treatment:yr_qtr2019.2",linetype = "dashed", colour = "red")+coord_flip()+theme(axis.text.x = element_text(angle = 90))
modelplot(hetmodel,vcov = cluster_vcovh,coef_omit = "^(?!did1:)",color="darkgreen")+geom_vline(xintercept=0)+labs(title="Heterogenous(Station) Average ULEZ Effects")
#Stargazer Tables with Jacknife and Clustered SE#
aic_row <- c("AIC", round(AIC(eventmodel), 2), round(AIC(hetmodel), 2), round(AIC(reducedmodel), 2))
bic_row <- c("BIC", round(BIC(eventmodel), 2), round(BIC(hetmodel), 2), round(BIC(reducedmodel), 2))
stargazer(hetmodel,reducedmodel,
          se=list(sqrt(diag(hcr_vcovh)),sqrt(diag(hcr_vcovr))),column.labels = c("Heterogeneous Model","Reduced Model"),add.lines = list(aic_row, bic_row),omit.stat = c("f", "ser"),
          header = FALSE,type = "text",title="Pollutant Levels,Station and Quarter FE,HC3(Jacknife)SE",omit = c("^Station", "yr_qtr"))
pm10GlasgowPlacebo <- boottest(reducedmodel,clustid="City",param="did1",type="webb",B=9999)
